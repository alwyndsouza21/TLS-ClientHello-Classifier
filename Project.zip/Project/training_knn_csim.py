import sys
sys.settrace
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import torch
import torch.nn.functional as F
from torch_geometric.loader import NeighborLoader
import torch_geometric.transforms as T
import time
import matplotlib.pyplot as plt
import ast, joblib
import pandas as pd
import numpy as np
from pandas.api.extensions import register_dataframe_accessor
import torch_geometric
import torch_sparse
from torch_geometric.nn import SAGEConv
from sklearn.preprocessing import StandardScaler
from torch_geometric.data import Data
import random
import gc
from torch_geometric.transforms import RandomNodeSplit
import numpy as np
import time
from sklearn.neighbors import NearestNeighbors
import tqdm
from sklearn.metrics import roc_curve, auc, RocCurveDisplay



device= "cpu"
print("Using Device:",device)


# Registering a custom accessor for pandas DataFrame
@register_dataframe_accessor("custom")
class CustomAccessor:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def add_label(self, label):
        """Adds a label column to the DataFrame."""
        self._obj["label"] = label
        return self._obj

# Reading and labeling data from CSV files
df_benign = pd.read_csv("pcap_capture_benign/benign.csv").custom.add_label(0)
df_malignant = (
    pd.read_csv("pcap_malicious_capture/malicious_12k.csv")
    .sample(frac=1)
    .reset_index(drop=True)
    .custom.add_label(1)
)
# print(df_malignant)
# print("benign shape:", df_benign.shape)


# Removing rows with MessageLen == 512 and resetting the index
df_malignant = df_malignant[df_malignant["MessageLen"] != 512].reset_index(drop=True)

# print("malignant shape:", df_malignant.shape)
# Merging and shuffling the DataFrames
df_merged = pd.concat([df_benign, df_malignant], axis=0).reset_index(drop=True)
df_shuffled = df_merged.sample(frac=1).reset_index(drop=True)

# Define a helper function to safely parse string representations of lists
def safe_list(x):
    try:
        return ast.literal_eval(x)
    except:
        return []

# Apply transformations to `df_shuffled`
df_shuffled['CipherSuite_Count'] = df_shuffled['CipherSuites'].apply(lambda x: len(safe_list(x)))
df_shuffled['SignatureAlgs_Count'] = df_shuffled['SignatureAlgs'].apply(lambda x: len(safe_list(x)))
df_shuffled['SupportedGroups_Count'] = df_shuffled['SupportedGroups'].apply(lambda x: len(safe_list(x)))
df_shuffled['SupportedPoints_Count'] = df_shuffled['SupportedPoints'].apply(lambda x: len(safe_list(x)))
df_shuffled['Extensions_Count'] = df_shuffled['Extensions'].apply(lambda x: len(safe_list(x)))
df_shuffled['CompressMethods_Count'] = df_shuffled['CompressMethods'].apply(lambda x: len(safe_list(x)))

# # Map TLS handshake versions to human-readable labels
# version_map = {
#     769: 'TLS 1.0',
#     770: 'TLS 1.1',
#     771: 'TLS 1.2',
#     772: 'TLS 1.3'
# }
# df_shuffled['HandshakeVersionLabel'] = df_shuffled['Version'].map(version_map)

# # Perform one-hot encoding on the HandshakeVersionLabel column
# df_shuffled = pd.get_dummies(df_shuffled, columns=['HandshakeVersionLabel'], prefix='Uses')
# for col in ['Uses_TLS 1.1', 'Uses_TLS 1.3']:
#     if col not in df_shuffled.columns:
#         df_shuffled[col] = 0
# for col in ['Uses_TLS 1.0', 'Uses_TLS 1.1', 'Uses_TLS 1.2', 'Uses_TLS 1.3']:
#     df_shuffled[col] = df_shuffled[col].astype(int)

# Drop unnecessary columns
df_shuffled.drop(columns=[
    'CipherSuites', 'SignatureAlgs', 'SupportedGroups', 'SupportedPoints',
    'CompressMethods', 'Extensions', 'Ja3', 'ALPNs', 'SrcIP', 'DstIP',
    'SrcPort', 'DstPort', 'SrcMAC', 'DstMAC', 'Random', 'SessionID',
    'Timestamp', 'SNI', 'OSCP', "CompressMethods_Count", "SessionIDLen",
    "HandshakeType", "HandshakeLen", "Type", "HandshakeVersion", "Version"
], inplace=True)

# Normalizing the DataFrame
df_shuffled["MessageLen"] = df_shuffled["MessageLen"].astype(str).str.replace(" ", "").astype(int)
# print("column order after dropping:", df_shuffled.columns)
scaler = StandardScaler()
cols_to_normalize = [col for col in df_shuffled.columns if col not in ["label"]]
# print("Columns to normalize:", cols_to_normalize)
df_shuffled.dropna(axis=0, inplace=True)
df_shuffled[cols_to_normalize] = scaler.fit_transform(df_shuffled[cols_to_normalize])
joblib.dump(scaler, 'scaler_without_tls_version.pkl')

def process_vertex_knn(index, V,k=10):
    vertice = np.array(V[index], dtype=np.float32).reshape(1,-1)
    all_other_indices = [i for i in range(len(V)) if i != index]
    if len(all_other_indices)==0:
        return [],[]
    knn= NearestNeighbors(n_neighbors=k+1, metric='cosine')
    if np.isnan(V).any():
        print("NaNs found in V")
        print(np.where(np.isnan(V)))
        raise ValueError("Feature matrix V contains NaN values.")
    knn.fit(V)
    distances, indices = knn.kneighbors(vertice)
    local_edges=[]
    local_weights=[]
    for sim_idx, neighbor_idx in enumerate(indices[0][1:]):
        local_edges.append([index, neighbor_idx])
        local_weights.append(1-distances[0][sim_idx+1])
    return local_edges, local_weights
def main_parallel_knn(df, k=10):
    df_copy_2 = df.copy()
    V = df_copy_2.values.tolist()
    # V = V[~np.isnan(V).any(axis=1)]
    print("Starting the processing...")

    E, Weights = [], []
    start_time = time.time()

    for index in tqdm.tqdm(range(len(V))):
        local_edges, local_weights = process_vertex_knn(index, V, k)
        E.extend(local_edges)
        Weights.extend(local_weights)
        

    end_time = time.time()
    print(f"\n✅ Processing completed in {(end_time - start_time) / 60:.2f} minutes")
    print(f"Total edges found: {len(E)}")

    return E, Weights, df_copy_2

# def process_vertex(index, V, T=0.95, gamma=0.1):
#     vertice = np.array(V[index], dtype=np.float32)
#     all_other_indices = [i for i in range(len(V)) if i != index]

#     if len(all_other_indices) == 0:
#         return [], [],  # No candidates available

#     # Select 500 random indices without replacement
#     # Select 500 random indices with replacement
#     candidate_indices = all_other_indices[:min(500, len(all_other_indices))]


#     if len(candidate_indices) == 0:
#         return [], [],  # Again, safe check

#     Candidate_V = np.array([V[i] for i in candidate_indices], dtype=np.float32)

#     if Candidate_V.shape[0] == 0:
#         return [], [],  # Still empty

#     a = torch.tensor(vertice).unsqueeze(0)  # (1, D)
#     b = torch.tensor(Candidate_V)           # (N, D)

#     if a.shape[1] != b.shape[1]:  # Extra safety for mismatch
#         print(f"[WARN] Shape mismatch: a={a.shape}, b={b.shape}")
#         return [], [],

#     # Compute similarity using the RBF kernel
#     sims = rbf_kernel(a, b, gamma)

#     local_edges = []
#     local_weights = []
#     for sim_idx, match in enumerate(sims):
#         if match >= T:
#             local_edges.append([index, candidate_indices[sim_idx]])
#             local_weights.append(match.item())

#     return local_edges, local_weights





# def process_vertex_ranking(index, V, k=100, gamma=0.1):
#     vertice = np.array(V[index], dtype=np.float32)
#     all_other_indices = [i for i in range(len(V)) if i != index]

#     if len(all_other_indices) == 0:
#         return [], [],  # No candidates available

#     # Compute similarity with all other vertices
#     Candidate_V = np.array([V[i] for i in all_other_indices], dtype=np.float32)
#     a = torch.tensor(vertice).unsqueeze(0)  # (1, D)
#     b = torch.tensor(Candidate_V)           # (N, D)

#     sims = rbf_kernel(a, b, gamma)

#     # Rank by similarity
#     ranked_indices = torch.argsort(sims, descending=True)[:k]
#     ranked_vals = sims[ranked_indices]

#     local_edges = []
#     local_weights = []

#     for idx, val in zip(ranked_indices, ranked_vals):
#             local_edges.append([index, all_other_indices[idx]])
#             local_weights.append(val.item())

#     return local_edges, local_weights


# # MAIN function to process all vertices
# def main_parallel(df):
#     df_copy_2 = df.copy()
#     V = df_copy_2.values.tolist()
#     print(f"Total nodes in dataset: {len(V)}")
#     print("Starting the processing...")

#     E, Weights = [], []
#     start_time = time.time()

#     for index in range(len(V)):
#         local_edges, local_weights = process_vertex_ranking(index, V)
#         E.extend(local_edges)
#         Weights.extend(local_weights)

#         if index % 100 == 0:
#             # print(f"Processed {index}/{len(V)} nodes.")
#             continue

#     end_time = time.time()
#     print(f"\n✅ Processing completed in {(end_time - start_time) / 60:.2f} minutes")
#     print(f"Total edges found: {len(E)}")

#     return E, Weights, df_copy_2

k_values=[5,10,15,20,30]
for k_value in k_values:

    Edge, _ ,_= main_parallel_knn(df_shuffled, k=k_value)
    # print(Edge[0])

    # Convert the DataFrame to a tensor
    # x = torch.tensor(df_shuffled[cols_to_normalize].values, dtype=torch.float32)  # Use float32 for efficiency


    x_np = df_shuffled[cols_to_normalize].to_numpy(dtype=np.float32)
    x = torch.from_numpy(x_np)

    y = torch.tensor(df_shuffled["label"].values, dtype=torch.long)

    # Optional: If memory issues occur, you can sample a subset of the data
    # df_shuffled = df_shuffled.sample(n=1000)  # For example, take 1000 rows

    # print("Edges and weights created")

    edge_index = torch.tensor(Edge, dtype=torch.long).t()
    print("Edges_Index created Successfuly!")
    data = Data(x=x, edge_index=edge_index, y=y)
    print("Data object created successfully!", data.x.shape)

    splitter = RandomNodeSplit(split='train_rest', num_test=0.2, num_val=0.0)

    # Apply the transformation to the data object
    data = splitter(data)
    print("data_split successfully")

    # Move data to the active device
    # data = data.to(device)

    # Creating the data loaders with reduced batch size
    train_loader = NeighborLoader(
        data,
        num_neighbors=[2,2],
        batch_size=16,  # Reduced batch size
        shuffle=False,
        num_workers=0,  # No additional workers to avoid multiprocessing issues
        input_nodes=data.train_mask,

    )
    print("train dataloader created!")
    print("train_mask shape:", data.train_mask.sum())
    test_loader = NeighborLoader(
        data,
        num_neighbors=[2,2],
        batch_size=16,  # Reduced batch size
        shuffle=False,
        num_workers=0,  # No additional workers
        input_nodes=data.test_mask,
    )
    print("test dataloader created!")
    print("test_mask shape:", data.test_mask.sum())

    # GraphSAGE model definition
    class GraphSage(torch.nn.Module):
        def __init__(self, in_channels, hidden_channels, out_channels):
            super(GraphSage, self).__init__()
            self.conv1 = SAGEConv(in_channels, hidden_channels)
            self.conv2 = SAGEConv(hidden_channels, out_channels)

        def forward(self, x, edge_index):
            x = self.conv1(x, edge_index)
            x = F.relu(x)
            x = F.dropout(x, training=self.training)
            x = self.conv2(x, edge_index)
            return F.log_softmax(x, dim=1)

    # Initialize the model, optimizer, and loss function
    in_channels = data.num_node_features
    print("in_channels:", in_channels)
    out_channels = len(data.y.unique())
    print("out_channels:", out_channels)
    hidden_channels = 64
    model = GraphSage(in_channels, hidden_channels, out_channels).to(device)
    print("model initialized!")
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # Function to plot confusion matrix
    def plot_confusion_matrix(y_true, y_pred):
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=['Benign', 'Malicious'], yticklabels=['Benign', 'Malicious'])
        plt.title("cosine similarity threshold: 0.85")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        plt.show()

    # Function to plot loss and accuracy graphs
    def plot_metrics_graphs(train_losses, test_accuracies):
        fig, ax1 = plt.subplots(figsize=(10, 6))

        # Plot training loss
        ax1.set_xlabel("Epochs")
        ax1.set_ylabel("Train Loss", color="tab:red")
        ax1.plot(range(1, len(train_losses) + 1), train_losses, color="tab:red", label="Train Loss")
        ax1.tick_params(axis="y", labelcolor="tab:red")

        # Plot test accuracy
        ax2 = ax1.twinx()  # Create a second y-axis
        ax2.set_ylabel("Test Accuracy", color="tab:blue")
        ax2.plot(range(1, len(test_accuracies) + 1), test_accuracies, color="tab:blue", label="Test Accuracy")
        ax2.tick_params(axis="y", labelcolor="tab:blue")

        plt.title("Train Loss and Test Accuracy per Epoch")
        plt.show()

    def plot_roc_curve(labels, probs, num_classes=2):
        plt.figure(figsize=(8, 6))
        
        # Convert labels and probs to numpy arrays
        labels = np.array(labels)
        probs = np.array(probs)
        
        # For binary or multi-class classification
        if num_classes == 2:
            # Binary classification: use the positive class probability
            fpr, tpr, _ = roc_curve(labels, probs[:, 1])
            roc_auc = auc(fpr, tpr)
            plt.plot(fpr, tpr, label=f'ROC curve (AUC = {roc_auc:.2f})')
        else:
            # Multi-class: One-vs-Rest ROC curves
            for i in range(num_classes):
                fpr, tpr, _ = roc_curve((labels == i).astype(int), probs[:, i])
                roc_auc = auc(fpr, tpr)
                plt.plot(fpr, tpr, label=f'Class {i} (AUC = {roc_auc:.2f})')
        
        plt.plot([0, 1], [0, 1], 'k--')  # Diagonal line
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC-AUC Curve')
        plt.legend(loc="lower right")
        plt.grid(True)
        plt.show()

    # Combined train and test function with metrics
    def train_and_test(train_loader, test_loader, model, optimizer, num_epochs=5, device=None):
        print("the train_and_test function has been called ....")
        train_losses = []
        test_accuracies = []
        
        # Training loop
        def train():
            print("Entered the training Loop.....")
            model.train()
            total_loss = 0
            correct = 0
            total = 0

            for batch in train_loader:
                batch = batch.to(device)
                optimizer.zero_grad()
                out = model(batch.x, batch.edge_index)

                mask = batch.train_mask
                loss = F.nll_loss(out[mask], batch.y[mask])

                loss.backward()
                optimizer.step()

                total_loss += loss.item()

                # Calculate accuracy
                pred = out[mask].max(dim=1)[1]
                correct += (pred == batch.y[mask]).sum().item()
                total += mask.sum().item()

            train_accuracy = correct / max(1, total)  # avoid division by zero
            return total_loss / len(train_loader), train_accuracy


    
        # def test():
        #     model.eval()
        #     correct = 0
        #     total = 0
        #     all_labels = []
        #     all_preds = []
            
        #     with torch.no_grad():
        #         for batch in test_loader:
        #             batch = batch.to(device)
        #             out = model(batch.x, batch.edge_index)
                    
        #             mask = batch.test_mask
        #             pred = out[mask].max(dim=1)[1]
                    
        #             correct += (pred == batch.y[mask]).sum().item()
        #             total += mask.sum().item()  # Count the actual number of test nodes in this batch
                    
        #             all_labels.extend(batch.y[mask].cpu().numpy())
        #             all_preds.extend(pred.cpu().numpy())
                    
        #     accuracy = correct / max(1, total)  # Avoid division by zero
        #     return accuracy, all_labels, all_preds
        def test():
            model.eval()
            correct = 0
            total = 0
            all_labels = []
            all_preds = []
            all_probs= []

            with torch.no_grad():
                for batch in test_loader:
                    batch = batch.to(device)
                    out = model(batch.x, batch.edge_index)

                    # The first `batch.batch_size` nodes are the actual test nodes
                    mask = torch.arange(batch.batch_size, device=out.device)

                    pred = out[mask].argmax(dim=1)
                    true = batch.y[mask]
                    probs = torch.softmax(out[mask], dim=1)

                    correct += (pred == true).sum().item()
                    total += true.size(0)

                    all_labels.extend(true.cpu().numpy())
                    all_preds.extend(pred.cpu().numpy())
                    all_probs.extend(probs.cpu().numpy())

            accuracy = correct / total if total > 0 else 0
            print("Total test nodes evaluated:", total)
            print("Correct predictions:", correct)
            return accuracy, all_labels, all_preds, all_probs

        # Training and testing per epoch
        train_accuracies = []  # Add this list to store train accuracies

        for epoch in range(num_epochs):
            train_loss, train_accuracy = train()
            test_accuracy, all_labels, all_preds, all_probs = test()

            train_losses.append(train_loss)
            train_accuracies.append(train_accuracy)
            test_accuracies.append(test_accuracy)

            print(f"Epoch {epoch + 1}/{num_epochs} - Train Loss: {train_loss:.4f}, Train Accuracy: {train_accuracy:.4f}, Test Accuracy: {test_accuracy:.4f}")

            if epoch== num_epochs-1:
                plot_roc_curve(all_labels, all_probs) 
            # Force garbage collection between epochs
            gc.collect()


            
        # Plot confusion matrix and show classification report
        plot_confusion_matrix(all_labels, all_preds)
        print(classification_report(all_labels, all_preds))
        torch.save(model.state_dict(),f"graphsage_model_without_TLS_version_k_value_{k_value}.pth")
        print("Model saved to graphsage_model.pth!!!")
        
        # Plot metrics graphs
        plot_metrics_graphs(train_losses, test_accuracies)


    # Run the training and testing process
    try:
        print("Starting training and testing...")
        train_and_test(train_loader, test_loader, model, optimizer, num_epochs=20, device=device)
        print("Training and testing completed successfully!")
    except Exception as e:
        print("Error during Training:",e)

