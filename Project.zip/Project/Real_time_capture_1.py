#import all the necessary modules
import subprocess, threading, time, queue, ast, hashlib, os, random, torch, torch_geometric, torch_sparse, joblib, multiprocessing
import numpy as np
import pandas as pd
import torch.nn.functional as F
import torch_geometric.transforms as T
from torch_geometric.data import Data
from torch_geometric.loader import NeighborLoader
from torch_geometric.nn import SAGEConv
from sklearn.preprocessing import StandardScaler
import time 
import tqdm 
from sklearn.neighbors import NearestNeighbors

packet_queue = queue.Queue()
interface = "en0"

device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

columns = ['Timestamp', 'SrcIP', 'DstIP', 'SrcMAC', 'DstMAC', 'SrcPort', 'DstPort',
           'Type', 'Version', 'MessageLen', 'HandshakeType', 'HandshakeLen', 
           'HandshakeVersion', 'Random', 'SessionIDLen', 'SessionID', 
           'CipherSuiteLen', 'ExtensionLen', 'CipherSuites', 'CompressMethods', 
           'SignatureAlgs', 'SupportedGroups', 'SupportedPoints', 'Ja3', 
           'Extensions', 'OSCP', 'SNI', 'ALPNs']

cmd = [
    "tshark",
    "-l",
    "-i", interface,
    "-Y", "tls.handshake.type == 1 and !quic and tcp",
    "-T", "fields",
    "-e", "frame.time",
    "-e", "ip.src",
    "-e", "ip.dst",
    "-e", "eth.src",
    "-e", "eth.dst",
    "-e", "tcp.srcport",
    "-e", "tcp.dstport",
    "-e", "tls.record.content_type",
    "-e", "tls.record.version",
    "-e", "tls.record.length",
    "-e", "tls.handshake.type",
    "-e", "tls.handshake.length",
    "-e", "tls.handshake.version",
    "-e", "tls.handshake.random",
    "-e", "tls.handshake.session_id_length",
    "-e", "tls.handshake.session_id",
    "-e", "tls.handshake.cipher_suites_length",
    "-e", "tls.handshake.extensions_length",
    "-e", "tls.handshake.ciphersuite",
    "-e", "tls.handshake.comp_methods",
    "-e", "tls.handshake.sig_hash_alg",
    "-e", "tls.handshake.extensions_supported_group",
    "-e", "tls.handshake.extensions_ec_point_formats",
    "-e", "tls.handshake.ja3",
    "-e", "tls.handshake.extension.type",
    "-e", "tls.handshake.extensions_status_request_type",
    "-e", "tls.handshake.extensions_server_name",
    "-e", "tls.handshake.extensions_alpn_str",
    "-E", "separator=#"
]


def tshark_capture_thread(cmd, q):
    print("THREAD1: tshark capture started")
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=1,
            text=True
        )
        for line in iter(process.stdout.readline, ""):
            line = line.strip()
            if line:
                q.put(line)
            # print(q.qsize())
        process.stdout.close()
        print("THREAD1: tshark capture completed")
    except Exception as e:
        print(f"Error in tshark capture thread: {e}")
def safe_list(x):
    try:
        if isinstance(x, str):
            return x.split(",")
        return list(x)
    except Exception as e:
        print(e)

def process_vertex_knn(index, V,k=5):
    vertice = np.array(V[index], dtype=np.float32).reshape(1,-1)
    all_other_indices = [i for i in range(len(V)) if i != index]
    if len(all_other_indices)==0:
        return [],[]
    knn= NearestNeighbors(n_neighbors=k+1, metric='cosine')
    if np.isnan(V).any():
        print("NaNs found in V")
        print(np.where(np.isnan(V)))
        raise ValueError("Feature matrix V contains NaN values.")
    knn.fit(V)
    distances, indices = knn.kneighbors(vertice)
    local_edges=[]
    local_weights=[]
    for sim_idx, neighbor_idx in enumerate(indices[0][1:]):
        local_edges.append([index, neighbor_idx])
        local_weights.append(1-distances[0][sim_idx+1])
    return local_edges, local_weights
def main_parallel_knn(df, k=10):
    df_copy_2 = df.copy()
    V = df_copy_2.values.tolist()
    # V = V[~np.isnan(V).any(axis=1)]
    print("Starting the processing...")

    E, Weights = [], []
    start_time = time.time()

    for index in tqdm.tqdm(range(len(V))):
        local_edges, local_weights = process_vertex_knn(index, V, k)
        E.extend(local_edges)
        Weights.extend(local_weights)
        

    end_time = time.time()
    print(f"\n✅ Processing completed in {(end_time - start_time) / 60:.2f} minutes")
    print(f"Total edges found: {len(E)}")

    return E, Weights, df_copy_2

#------------MODEL DEFINITION----------------
class GraphSage(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GraphSage, self).__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, out_channels)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)
        return F.log_softmax(x, dim=1)
    
in_channels = 8
hidden_channels = 64
out_channels = 2
model = GraphSage(in_channels, hidden_channels, out_channels).to(device)
model.load_state_dict(torch.load("graphsage_model_without_TLS_version.pth", map_location=torch.device(device)))

#packet processing in real time, pope leo
def packet_processing(q):
    print("THREAD2: packet processing started")
    all_rows = []
    sni_list = []
    while True:
        if q.qsize() > 10:
            print("THREAD2: ten packets captured, processing...")
            packets = []
            try:
                while not q.empty():
                    pkt = q.get_nowait()
                    packets.append(pkt)
                    # print("packet appended to the list from Queue!")
            except queue.Empty:
                pass
          
            for idx, packet in enumerate(packets):
                fields = packet.split("#")
                if len(fields) == len(columns):  # Check if fields match expected column count
                    try:
                        # All fields are already in the right order from tshark
                        row = fields
                        all_rows.append(row)
                        # Extract SNI for later use
                        sni = fields[26]  # Index for SNI in columns list
                        sni_list.append(sni)
                    except Exception as e:
                        print(f"❌ Error parsing packet: {e}")
                else:
                    print(f"Packet skipped, contains {len(fields)} fields instead of expected {len(columns)}!")
                    
            if all_rows:
                df = pd.DataFrame(all_rows, columns=columns)
                all_rows = []
                # Apply transformations to `df`
                df['CipherSuite_Count'] = df['CipherSuites'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)
                df['SignatureAlgs_Count'] = df['SignatureAlgs'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)
                df['SupportedGroups_Count'] = df['SupportedGroups'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)
                df['SupportedPoints_Count'] = df['SupportedPoints'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)
                df['Extensions_Count'] = df['Extensions'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)
                df['CompressMethods_Count'] = df['CompressMethods'].apply(lambda x: len(safe_list(x))).replace(",","").astype(int)

                # # Map TLS handshake versions to human-readable labels
                # version_map = {
                #     769: 'TLS 1.0',
                #     770: 'TLS 1.1',
                #     771: 'TLS 1.2',
                #     772: 'TLS 1.3'
                # }

                # df['HandshakeVersionLabel'] = df['Version'].map(version_map)

                # # Perform one-hot encoding on the HandshakeVersionLabel column
                # df = pd.get_dummies(df, columns=['HandshakeVersionLabel'], prefix='Uses')

                # # Ensure all expected columns are present (including 'Uses_TLS 1.0', 'Uses_TLS 1.1', etc.)
                # for col in ['Uses_TLS 1.0', 'Uses_TLS 1.1', 'Uses_TLS 1.2', 'Uses_TLS 1.3']:
                #     if col not in df.columns:
                #         df[col] = 0  # If the column is missing, add it with default value 0

                # # Convert columns to integer type
                # for col in ['Uses_TLS 1.0', 'Uses_TLS 1.1', 'Uses_TLS 1.2', 'Uses_TLS 1.3']:
                #     df[col] = df[col].astype(int)

                # Drop unnecessary columns
                columns_to_drop = [
                    'CipherSuites', 'SignatureAlgs', 'SupportedGroups', 'SupportedPoints',
                    'CompressMethods', 'Extensions', 'Ja3', 'ALPNs', 'SrcIP', 'DstIP',
                    'SrcPort', 'DstPort', 'SrcMAC', 'DstMAC', 'Random', 'SessionID',
                    'Timestamp', 'SNI', 'OSCP', "CompressMethods_Count", "SessionIDLen",
                    "HandshakeType", "HandshakeLen", "Type", "HandshakeVersion", "Version"
                ]
                
                # Only drop columns that actually exist in the DataFrame
                existing_columns = [col for col in columns_to_drop if col in df.columns]
                df.drop(columns=existing_columns, inplace=True)
                # print(f"Remaining columns after drop: {df.columns}")
                # Reorder columns to match the order used during scaler training
                required_column_order = [
                    'MessageLen', 'CipherSuiteLen', 'ExtensionLen', 'CipherSuite_Count', 
                    'SignatureAlgs_Count', 'SupportedGroups_Count', 'SupportedPoints_Count', 
                    'Extensions_Count']
                
                print("Columns in the dataframe:", df.columns)
                # Reorder the columns in the DataFrame
                df["MessageLen"] = df["MessageLen"].astype(str).str.replace(",", "").astype(int)
                df = df[required_column_order]
                # print("columns after reordering:",df.columns)

                # Load the scaler
                try:
                    scaler = joblib.load("scaler_without_tls_version.pkl")
                    # Only normalize columns that exist
                    cols_to_normalize = [col for col in df.columns]
                    if cols_to_normalize:  # Check if there are any columns to normalize
                        df[cols_to_normalize] = scaler.transform(df[cols_to_normalize])
                except Exception as e:
                    print(f"Error during normalization: {e}")
                    continue  # Skip this batch if normalization fails

                # Process graph and make predictions
                try:
                    E, Weights, df = main_parallel_knn(df)
                    if len(E) == 0:  # No edges found
                        print("No edges found in the graph. Skipping this batch.")
                        continue
                        
                    x = torch.tensor(df.values, dtype=torch.float)
                    edge_index = torch.tensor(E, dtype=torch.long).t().contiguous()
                    edge_attr = torch.tensor(Weights, dtype=torch.float)
                    data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr)
                    
                    # Create data loader
                    train_loader = NeighborLoader(
                        data,
                        num_neighbors=[2, 2],
                        batch_size=2,
                        input_nodes=torch.arange(data.num_nodes)
                    )
                    
                    # Move data to device
                    data = data.to(device)
                    
                    # Inference
                    predictions = []
                    model.eval()
                    with torch.no_grad():
                        for batch in train_loader:
                            batch = batch.to(device)
                            out = model(batch.x, batch.edge_index)
                            pred = out.argmax(dim=1).cpu().numpy()
                            predictions.extend(pred)

                    # Show predictions alongside Website (SNI)
                    print("\n🔮 Predictions:")
                    print(f"{'Domain Name':<30} | {'Status':<15}")
                    print("-" * 50)

                    for sni, pred in zip(sni_list, predictions):
                        status = "Benign 👌" if pred == 1 else "Malicious ⚠️"
                        print(f"{sni:<30} | {status:<15}")

                    sni_list = []  # Clear for next batch
                
                except Exception as e:
                    print(f"Error during graph processing or inference: {e}")
                    continue
        
        time.sleep(1)  # Add a small delay to prevent CPU hogging

# Start the threads
thread_1 = threading.Thread(target=tshark_capture_thread, args=(cmd, packet_queue), daemon=True)
thread_2 = threading.Thread(target=packet_processing, args=(packet_queue,), daemon=True)

thread_1.start()
thread_2.start()

# Keep the main thread alive
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\n[!] Exiting...")